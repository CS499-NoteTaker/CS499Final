package Server.Resources;
import org.junit.*;

import javax.ws.rs.core.Response;

public class DocumentResourceTest {
    @Test
    public Response createpdf2(String src){
        return null;
    }
}
