package Core;
import org.junit.*;
public class ControllerTest {
    @Test
    public String getCell(){
        return null;
    }
    @Test
    public ResearchedCells getAllCell(){
        return null;
    }
}
