package Core;
import org.junit.*;

public class ResearchedCellsTest {
    @Test
    public void testGetCells() {
    }
}
