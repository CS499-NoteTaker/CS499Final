package Core;
import org.junit.*;
public class ResearchedCellsHandlerTest {
    @Test
    public void testGetCellByCell() {
    }
    @Test
    public void testGetResearchedCells() {
    }
}
