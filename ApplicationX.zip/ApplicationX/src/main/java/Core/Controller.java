package Core;

public class Controller {

    /*

     */
    private ResearchedCellsHandler manager;

    public String getCell(){
        return null;
    }



}
