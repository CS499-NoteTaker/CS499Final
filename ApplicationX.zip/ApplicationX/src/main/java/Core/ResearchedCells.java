package Core;

public class ResearchedCells {
    String [] htmlContentCells;
    public ResearchedCells(){
    }

    public String [] getCells(){
        return htmlContentCells;
    }

}
