package Server.Resources;

public class AIResource {
}
